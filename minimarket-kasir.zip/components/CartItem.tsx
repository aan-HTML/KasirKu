
import React from 'react';
import { CartItem } from '../types';
import { PlusIcon, MinusIcon, TrashIcon } from './Icons';

interface CartItemProps {
  item: CartItem;
  onIncrease: (id: number) => void;
  onDecrease: (id: number) => void;
  onRemove: (id: number) => void;
  formatCurrency: (amount: number) => string;
}

const CartItemComponent: React.FC<CartItemProps> = ({ item, onIncrease, onDecrease, onRemove, formatCurrency }) => {
  return (
    <div className="flex items-center space-x-3 p-2 rounded-lg hover:bg-slate-50 transition-colors">
      <img src={item.imageUrl} alt={item.name} className="w-16 h-16 object-cover rounded-md" />
      <div className="flex-grow">
        <p className="font-semibold text-slate-800 text-sm">{item.name}</p>
        <p className="text-xs text-slate-500">{formatCurrency(item.price)}</p>
        <div className="flex items-center mt-1">
          <button onClick={() => onDecrease(item.id)} className="p-1 rounded-full bg-slate-200 hover:bg-slate-300 transition-colors">
            <MinusIcon className="w-4 h-4 text-slate-600" />
          </button>
          <span className="px-3 text-sm font-bold w-10 text-center">{item.quantity}</span>
          <button onClick={() => onIncrease(item.id)} className="p-1 rounded-full bg-slate-200 hover:bg-slate-300 transition-colors">
            <PlusIcon className="w-4 h-4 text-slate-600" />
          </button>
        </div>
      </div>
      <div className="flex flex-col items-end">
        <p className="font-bold text-slate-800 text-sm">{formatCurrency(item.price * item.quantity)}</p>
         <button onClick={() => onRemove(item.id)} className="text-slate-400 hover:text-red-500 transition-colors mt-2">
            <TrashIcon className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default CartItemComponent;
