
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  formatCurrency: (amount: number) => string;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, formatCurrency }) => {
  return (
    <div
      onClick={() => onAddToCart(product)}
      className="bg-white rounded-lg shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col overflow-hidden group"
    >
      <div className="relative overflow-hidden">
        <img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-32 object-cover group-hover:scale-110 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-black bg-opacity-20 group-hover:bg-opacity-10 transition-all duration-300"></div>
      </div>
      <div className="p-3 flex flex-col flex-grow">
        <h3 className="text-sm font-semibold text-slate-800 flex-grow">{product.name}</h3>
        <p className="text-md font-bold text-blue-600 mt-2">{formatCurrency(product.price)}</p>
      </div>
    </div>
  );
};

export default ProductCard;
